# Django_APIView
Implement a base generic view for handling model RESTful endpoints
